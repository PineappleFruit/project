/**
 * Created by Administrator on 2017/5/5.
 */
$(function () {
    // $(".return_top_i").hide();
    $(window).scroll(function () {
        // console.log($(window).scrollTop());
        if ($(window).scrollTop() >100){
            // $(".return_top i").removeClass("hide_i");
            // $(".return_top i").addClass("show_i")
            $(".return-top").addClass('active')

        }else {
            // $(".return_top i").removeClass("show_i");
            // $(".return_top i").addClass("hide_i")
            $(".return-top").removeClass('active')

        };
        
        var scrollTop = $(this).scrollTop();
        var scrollHeight = $(document).height();
        var windowHeight = $(this).height();
        if(scrollTop + windowHeight == scrollHeight){
        	var test = `<div class="ub ub-pj ub-ac mb20">
				      			<div class="ub ub-f1">
				      				<div class="card-pic mr20">
				      					<img src="images/2.png" alt="" />
				      				</div>
				      				<div class="ub-f1 ub-te tx-l">
				      					<p class="fz26 c3d ub-te">id</p>
				      					<p class="c99 fz26">2018-06-19 15:45</p>
				      				</div>
				      			</div>
				      			<span class="fz26 c-blue">砍至底价6</span>
				      		</div>`
        	$(".ranking-info").append(test)
        }
    })
    $(".return-top").click(function () {
//      document.documentElement.scrollTop = document.body.scrollTop = 0;
		$('html , body').animate({scrollTop: 0},'slow');
    });
    
    $(".cut-btn").click(function (){
    	$(".masking").addClass('active')
    })
    $(".dialog").click(function(){
    	$(".masking").removeClass('active')
    })
  	$(".close").click(function(){
  		$(".fixed-ft").removeClass('active')
  	})
  	
//	设置进度
	$(".progress-bar-con").css('width','30%')
})