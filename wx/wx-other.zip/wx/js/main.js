/**
 * Created by Administrator on 2017/5/5.
 */
$(function() {
	$(window).scroll(function() {
		if($(window).scrollTop() > 100) {
			$(".return-top").addClass('active')

		} else {
			$(".return-top").removeClass('active')

		};
	})
	$(".return-top").click(function() {
		$("body,html").animate({
			scrollTop: 0
		})
	});

	$(".cut-btn").click(function() {
		$(".masking").addClass('active')
	})
	$(".dialog").click(function() {
		$(".masking").removeClass('active')
	})
	$(".close").click(function() {
		$(".fixed-ft").removeClass('active')
	})
})