function count(data){
	function GetRTime(){
        var EndTime= new Date(data.time.replace(/\-/,"-"));
        var NowTime = new Date();
        var t =EndTime.getTime() - NowTime.getTime();
        var hour=0;
        var minute=0;
        var second=0;
        if(t>=0){
            d=Math.floor(t/1000/60/60/24);
            hour=Math.floor(t/1000/60/60%24);
            minute=Math.floor(t/1000/60%60);
            second=Math.floor(t/1000%60);
        }

        function checkTime(x){
            if (x < 10){
                {x='0'+x}

            }
            return x;
        }
        day = checkTime(d)
        hour = checkTime(hour);
        minute =  checkTime(minute);
        second =  checkTime(second);
		data.el.find($(".time_content_day")).text(day);
        data.el.find($(".time_content_hour")).text(hour);
        data.el.find($(".time_content_minute")).text(minute);
        data.el.find($(".time_content_second")).text(second);
    }
//	GetRTime()
    setInterval(GetRTime,1000);
}
