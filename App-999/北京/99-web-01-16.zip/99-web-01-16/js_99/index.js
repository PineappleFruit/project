$(function() {

	//关注微信
	$('.guanzhu,.mobile').on('mouseover', function() {
		$(this).children('.weixin').show();
		$(this).children('a').addClass('active');
	})
	$('.guanzhu,.mobile').on('mouseout', function() {
		$(this).children('.weixin').hide();
		$(this).children('a').removeClass('active');
	})

	//我的99网街
	$(".section1Top li").mouseenter(function() {
		$(this).addClass("active").siblings().removeClass("active");
		$(".index-c1-main").eq($(this).index()).addClass("active").siblings().removeClass("active");
	});

	$(".mxlright-tab li").click(function() {
		$(this).addClass("active").siblings().removeClass("active");
		$(this).parents(".mxlright-tab-cantaier").siblings(".h-right-box").find(".h-right-main").eq($(this).index()).addClass("active").siblings(".h-right-main").removeClass("active");
	})
	//搜索
	$(".h-search-form label").click(function() {
		$(this).parent().addClass("active")
	});
	$(".h-search-form li").click(function() {
		$(this).parents(".h-search-form").removeClass("active").attr("seachetype", $(this).attr("data-ttpe")).find("label").html($(this).html())
	});
	//查询档期
	$(".seeschedule-btn").click(function() {
		$(".mxlschedule").addClass("active")
	});
	$(".query-c1-btn").click(function() {
		$(this).parents(".query-gradeer").removeClass("active");
		$(".query-grade-c2").addClass("active")
	});
	$("#rsv_a1").click(function() {
		$(this).parents(".query-gradeer").removeClass("active");
		$(".query-grade-c1").addClass("active")
	});
	$("#rsv_a2").click(function() {
		$(this).parents(".mxlschedule").removeClass("active")
	});
	$("#rsv_get_radm").click(function() {
		$(this).parents(".query-gradeer").removeClass("active");
		$(".query-grade-c3").addClass("active")
	});

	//查询结果
	$(".seeselect-result-btn").click(function() {
		$(".selectResult-container").addClass("active")
	});
	$(".selectResult-close-btn").click(function() {
		$(this).parents(".selectResult-container").removeClass("active")
	});
	//查询结果->立即提交
	$(".selectResult-btn").click(function() {
		$(this).parents(".selectResult-container").removeClass("active")
	})
})

function indexBanner(time, speed) {
	var iNow = 0;
	var Timer;

	function indexBannerTab() {
		$(".index-banner-hd li").eq(iNow).stop().fadeOut(speed);
		iNow++
		iNow = iNow % $(".index-banner-hd li").length
		$(".index-banner-hd li").eq(iNow).stop().fadeIn(speed);
		$(".index-banner-bd li").eq(iNow).addClass("active").siblings().removeClass("active")
	}
	$(".index-banner-bd li").click(function() {
		iNow = $(this).index();
		$(".index-banner-hd li").eq(iNow).stop().fadeIn(speed).siblings().stop().fadeOut(speed);
		$(".index-banner-bd li").eq(iNow).addClass("active").siblings().removeClass("active")

	})
	Timer = setInterval(indexBannerTab, time);
	$(".index-banner").hover(function() {
		clearInterval(Timer)
	}, function() {
		Timer = setInterval(indexBannerTab, 2000);
	});
	$(".query-grade-tab a").click(function() {
		$(this).addClass("active").siblings().removeClass("active")
		if($(this).index() == 1) {
			$(".timeRange-other").addClass("active")
		} else {
			$(".timeRange-other").removeClass("active")

		}
	});
	//楼层js
	$(".index-c2-list-nav li").click(function(){
		$(this).addClass("active").siblings().removeClass("active")
		$("body,html").animate({
			"scrollTop":$(this).parents(".index-c2-list-wrap").find(".h-road-container").eq($(this).index()).offset().top
		});
	});
}